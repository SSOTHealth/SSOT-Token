export const constants = {
    NULL_BYTES: '0x',
    INVALID_OPCODE: 'invalid opcode',
};
