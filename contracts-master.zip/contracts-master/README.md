This repo is **DEPRECATED** and moved over to our [monorepo](https://github.com/0xProject/0x.js/tree/development/packages/contracts).
